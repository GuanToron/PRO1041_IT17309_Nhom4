

package Application;


import View.MainApp;


public class DuAn1 {

    public static void main(String[] args) {
         new MainApp().setVisible(true);
    }
}
