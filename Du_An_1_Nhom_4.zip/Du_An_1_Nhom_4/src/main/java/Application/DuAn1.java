

package Application;


import View.FormQLDanhMuc;
import View.FormSanPhamLoi;
import View.Formkh;
import View.MainApp;
import View.QLChucVu;


public class DuAn1 {

    public static void main(String[] args) {
         new MainApp().setVisible(true);
    }
}
